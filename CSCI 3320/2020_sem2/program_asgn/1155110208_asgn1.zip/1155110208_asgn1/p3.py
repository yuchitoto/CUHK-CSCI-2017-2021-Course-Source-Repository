
######################################################
######################################################
###############       problem 3      #################
######################################################
######################################################

import pandas
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

input3 = pandas.read_csv("input_3.csv")

#splitting dataset [training/testing]
cut_pt = int(0.8*len(input3))
input3_train, input3_test = input3.iloc[:cut_pt], input3.iloc[cut_pt:]
x3_test1, x3_test2, y3_test = input3_test['feature_value_1'], input3_test['feature_value_2'], input3_test['class']

#splitting train dataset accord to class
grouped = input3_train.groupby('class')
classes={}
for c, data in grouped:
    classes[c] = data

#visualize
from mpl_toolkits.mplot3d import Axes3D
base = len(classes[1]) + len(classes[2]) + len(classes[3])

#             s=len(classes[2])/(base)*100)
plt.scatter(classes[1]['feature_value_1'], classes[1]['feature_value_2'],            color='r', alpha=0.02, s=100)
plt.scatter(classes[2]['feature_value_1'], classes[2]['feature_value_2'],            color='b', alpha=0.02, s=100)
plt.scatter(classes[3]['feature_value_1'], classes[3]['feature_value_2'],            color='g', alpha=0.02, s=100)

plt.legend(["class 1","class 2","class 3"])

plt.show()

#visualize but the class size are too similar and only single feature with 2 possible value
from mpl_toolkits.mplot3d import Axes3D
base = len(classes[1]) + len(classes[2]) + len(classes[3])
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(classes[1]['feature_value_1'],classes[1]['feature_value_2'],           classes[1]['class'], color='r', alpha=0.3)
ax.scatter(classes[2]['feature_value_1'], classes[2]['feature_value_2'],           classes[2]['class'], color='b')
ax.scatter(classes[3]['feature_value_1'], classes[3]['feature_value_2'],           classes[3]['class'], color='g')
ax.legend(["class 1","class 2","class 3"])
ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')
plt.show()

#discriminant func: gi(x) = add two equa 
pC1 = len(classes[1])/len(input3_train)
pC2 = len(classes[2])/len(input3_train)
pC3 = len(classes[3])/len(input3_train)
pCi = [pC1, pC2, pC3]
print("pCi value: ",pCi)

#calc mean_i
mean1 = classes[1]['feature_value_2'].mean()
mean2 = classes[2]['feature_value_2'].mean()
mean3 = classes[3]['feature_value_2'].mean()
mean_list = [mean1, mean2, mean3]
print("mean value: ", mean_list)

#calc sd
sd1 = np.sqrt(((classes[1]['feature_value_2']-mean1)**2).sum()/len(classes[1]))
sd2 = np.sqrt(((classes[2]['feature_value_2']-mean2)**2).sum()/len(classes[2]))
sd3 = np.sqrt(((classes[3]['feature_value_2']-mean3)**2).sum()/len(classes[3]))
sd_list = [sd1, sd2, sd3]
print("variance value: ", list(map(lambda x: x**2, sd_list)))

#calc pi
p1 = (classes[1]['feature_value_1']==1).sum()/len(classes[1])
p2 = (classes[2]['feature_value_1']==1).sum()/len(classes[2])
p3 = (classes[3]['feature_value_1']==1).sum()/len(classes[3])
pi = [p1, p2, p3]
print("pi value: ",pi)

#discriminant
def g(x1, x2 ,class_no):
    i = class_no-1
    return (1/2)*np.log(2*np.pi) - np.log(sd_list[i]) -           (x2-mean_list[i])**2/(2*sd_list[i]**2) +           np.log(pi[i]**x1)+np.log((1-pi[i])**(1-x1))+np.log(pCi[i])*2

#testing
y2_pred1 = np.asarray([g(x3_test1, x3_test2,1)])
y2_pred2 = np.asarray([g(x3_test1, x3_test2,2)])
y2_pred3 = np.asarray([g(x3_test1, x3_test2,3)])
result_distribution = np.concatenate((y2_pred1, y2_pred2, y2_pred3)).transpose()
print(result_distribution)

#result
result = np.argmax((result_distribution), axis = 1) + 1
print("testcase_number  "+"feature_value_1  "+"feature_value_2  "+"classify_result","expected_result")
for i in range(len(result)):
    print(i,'\t\t',str.format('{0:.3f}\t\t', x3_test1.iloc[i]),str.format('{0:.3f}\t\t', x3_test2.iloc[i]),result[i],'\t\t',y3_test.iloc[i])

print('accuracy: ',(y3_test==result).sum(),'/',len(y3_test))


def confusion_matrix():
    #pirj = predicted result i and actual result j
    p1r1, p1r2, p1r3, p2r1, p2r2, p2r3, p3r1, p3r2, p3r3 = 0,0,0,0,0,0,0,0,0
    for i in range(len(y3_test)):
        if(y3_test.iloc[i]==1):
            if(result[i]==1): p1r1+=1
            elif(result[i]==2): p2r1+=1
            else: p3r1+=1
        elif(y3_test.iloc[i]==2):
            if(result[i]==1): p1r2+=1
            elif(result[i]==2): p2r2+=1
            else: p3r2+=1
        else:
            if(result[i]==1): p1r3+=1
            elif(result[i]==2): p2r3+=1
            else: p3r3+=1
    print('\t\t\033[96mpredict\033[0;0m\t')
    print('\t\t\033[96m1\t2\t3\033[0;0m')
    print('\t\033[96m1\033[0;0m\t'+'\033[1m'+str(p1r1)+'\t'+str(p2r1)+'\t'+str(p3r1)+'\033[0;0m')
    print('\033[96mactual\t2\033[0;0m\t'+'\033[1m'+str(p1r2)+'\t'+str(p2r2)+'\t'+str(p3r2)+'\033[0;0m')
    print('\t\033[96m3\033[0;0m\t'+'\033[1m'+str(p1r3)+'\t'+str(p2r3)+'\t'+str(p3r3)+'\033[0;0m')
    return "\033[96m---------confusion_matrix---------\033[0;0m"
print(confusion_matrix())
print("acc: ",(y3_test==result).sum()/len(y3_test))

#visualization of result
#p(x|Ci)
input_pt = np.linspace(-10,20, num = 1000)
plt.plot(input_pt, stats.norm.pdf(input_pt,mean1,sd1), 'r',         input_pt, stats.norm.pdf(input_pt,mean2,sd2), 'g',         input_pt, stats.norm.pdf(input_pt,mean3,sd3), 'b')
plt.xlim(-5,20)
plt.xlabel('x value')
plt.legend(['class1','class2','class3'])
plt.title('p(x|Ci) distribution')
plt.show()


#logp(Ci|x)
input_pt = np.linspace(-20,100, num = 1000)
plt.plot(input_pt, g(input_pt,input_pt,1), 'r',         input_pt, g(input_pt,input_pt,2), 'g',         input_pt, g(input_pt,input_pt,3), 'b')
plt.ylim(-20,30)
plt.xlim(-20,100)
plt.xlabel('x value')
plt.legend(['class1','class2','class3'])
plt.title('log p(Ci|x) distribution')
plt.show() 



