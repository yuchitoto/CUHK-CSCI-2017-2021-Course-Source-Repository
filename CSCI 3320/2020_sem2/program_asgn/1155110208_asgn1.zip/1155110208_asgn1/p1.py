
######################################################
######################################################
###############       problem 1      #################
######################################################
######################################################

import pandas
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats


#dataset reading
input1 = pandas.read_csv("input_1.csv")

#splitting dataset [training/testing]
cut_pt = int(0.8*len(input1))
input1_train, input1_test = input1.iloc[:cut_pt], input1.iloc[cut_pt:]
x_test, y_test = input1_test['feature_value'], input1_test['class']

#splitting train dataset accord to class
grouped = input1_train.groupby('class')
classes={}
for c, data in grouped:
    classes[c] = data

#visualize but the class size are too similar and only single feature with 2 possible value
base = len(classes[1]) + len(classes[2]) + len(classes[3])
plt.scatter(classes[1]['feature_value'], classes[1]['class'], color='r', 
            s=len(classes[1])/(base)*100)
plt.scatter(classes[2]['feature_value'], classes[2]['class'], color='b', 
            s=len(classes[2])/(base)*100)
plt.scatter(classes[3]['feature_value'], classes[3]['class'], color='g', 
            s=len(classes[3])/(base)*100)
plt.show()

#discriminant func: argmax(i) gi(x)=log(pi^x) + log((1-pi)^(1-x)) + logP(Ci)
total_num = len(input1_train)
pC1 = len(classes[1])/total_num
pC2 = len(classes[2])/total_num
pC3 = len(classes[3])/total_num
pCi = [pC1, pC2, pC3]
print("pCi value: ",pCi)

p1 = (classes[1]['feature_value']==1).sum()/len(classes[1])
p2 = (classes[2]['feature_value']==1).sum()/len(classes[2])
p3 = (classes[3]['feature_value']==1).sum()/len(classes[3])
pi = [p1, p2, p3]
print("pi value: ",pi)


def gi(x,class_no):
    i = class_no - 1
    return np.log(pi[i]**x)+np.log((1-pi[i])**(1-x))+np.log(pCi[i])

#testing
y_pred1 = np.asarray([gi(x_test,1)])
y_pred2 = np.asarray([gi(x_test,2)])
y_pred3 = np.asarray([gi(x_test,3)])
result_distribution = np.concatenate((y_pred1, y_pred2, y_pred3)).transpose()
print(result_distribution)

#result
result = np.argmax((result_distribution), axis = 1) + 1
print("testcase_number  "+"feature_value  "+"classify_result","expected_result")
for i in range(len(result)):
    print(i,'\t\t',x_test.iloc[i],'\t\t',result[i],'\t\t',y_test.iloc[i])

print('accuracy: ',(y_test==result).sum(),'/',len(y_test))

def confusion_matrix():
    #pirj = predicted result i and actual result j
    p1r1, p1r2, p1r3, p2r1, p2r2, p2r3, p3r1, p3r2, p3r3 = 0,0,0,0,0,0,0,0,0
    for i in range(len(y_test)):
        if(y_test.iloc[i]==1):
            if(result[i]==1): p1r1+=1
            elif(result[i]==2): p2r1+=1
            else: p3r1+=1
        elif(y_test.iloc[i]==2):
            if(result[i]==1): p1r2+=1
            elif(result[i]==2): p2r2+=1
            else: p3r2+=1
        else:
            if(result[i]==1): p1r3+=1
            elif(result[i]==2): p2r3+=1
            else: p3r3+=1
    print('\t\t\033[96mpredict\033[0;0m\t')
    print('\t\t\033[96m1\t2\t3\033[0;0m')
    print('\t\033[96m1\033[0;0m\t'+'\033[1m'+str(p1r1)+'\t'+str(p2r1)+'\t'+str(p3r1)+'\033[0;0m')
    print('\033[96mactual\t2\033[0;0m\t'+'\033[1m'+str(p1r2)+'\t'+str(p2r2)+'\t'+str(p3r2)+'\033[0;0m')
    print('\t\033[96m3\033[0;0m\t'+'\033[1m'+str(p1r3)+'\t'+str(p2r3)+'\t'+str(p3r3)+'\033[0;0m')
    return "\033[96m---------confusion_matrix---------\033[0;0m"
print(confusion_matrix())
print("acc: ",(y_test==result).sum()/len(y_test))

