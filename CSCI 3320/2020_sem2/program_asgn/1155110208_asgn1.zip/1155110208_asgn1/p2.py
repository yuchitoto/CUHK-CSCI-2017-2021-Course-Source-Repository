
######################################################
######################################################
###############       problem 2      #################
######################################################
######################################################

import pandas
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

input2 = pandas.read_csv("input_2.csv")

#splitting dataset [training/testing]
cut_pt = int(0.8*len(input2))
input2_train, input2_test = input2.iloc[:cut_pt], input2.iloc[cut_pt:]
x2_test, y2_test = input2_test['feature_value'], input2_test['class']

#splitting train dataset accord to class
grouped = input2_train.groupby('class')
classes={}
for c, data in grouped:
    classes[c] = data

#visualize but the class size are too similar and only single feature with 2 possible value
base = len(classes[1]) + len(classes[2]) + len(classes[3])
plt.scatter(classes[1]['feature_value'], [1]*len(classes[1]), color='r',            s=100, alpha=0.02)
plt.scatter(classes[2]['feature_value'], [1]*len(classes[2]), color='b',            s=100, alpha=0.02)
plt.scatter(classes[3]['feature_value'], [1]*len(classes[3]), color='g',            s=100, alpha=0.02)
plt.legend(["class 1","class 2","class 3"])
plt.show()

#separate layers
base = len(classes[1]) + len(classes[2]) + len(classes[3])
plt.scatter(classes[1]['feature_value'], classes[1]['class'], color='r', 
            s=len(classes[1])/(base)*100)
plt.scatter(classes[2]['feature_value'], classes[2]['class'], color='b', 
            s=len(classes[2])/(base)*100)
plt.scatter(classes[3]['feature_value'], classes[3]['class'], color='g', 
            s=len(classes[3])/(base)*100)
plt.legend(["class 1","class 2","class 3"])
plt.show()

#discriminant func: gi(x) = -1/2 log(2pi) - log(sd) - (x - mean)^2/(2*sd^2) + log P(Ci)
#Calc P(Ci)
pC1 = len(classes[1])/len(input2_train)
pC2 = len(classes[2])/len(input2_train)
pC3 = len(classes[3])/len(input2_train)
pCi = [pC1, pC2, pC3]
print("pCi value: ",pCi)

#calc mean_i
mean1 = classes[1]['feature_value'].mean()
mean2 = classes[2]['feature_value'].mean()
mean3 = classes[3]['feature_value'].mean()
mean_list = [mean1, mean2, mean3]
print("mean value: ", mean_list)

#calc sd (not using std as it calc (n/n-1)*s^2)
sd1 = np.sqrt(((classes[1]['feature_value']-mean1)**2).sum()/len(classes[1]))
sd2 = np.sqrt(((classes[2]['feature_value']-mean2)**2).sum()/len(classes[2]))
sd3 = np.sqrt(((classes[3]['feature_value']-mean3)**2).sum()/len(classes[3]))
sd_list = [sd1, sd2, sd3]
print("variance value: ", list(map(lambda x: x**2, sd_list)))

#discriminant
def g(x,class_no):
    i = class_no-1
    return (1/2)*np.log(2*np.pi) - np.log(sd_list[i]) -           (x-mean_list[i])**2/(2*(sd_list[i]**2)) + np.log(pCi[i])

#testing
y2_pred1 = np.asarray([g(x2_test,1)])
y2_pred2 = np.asarray([g(x2_test,2)])
y2_pred3 = np.asarray([g(x2_test,3)])
result_distribution = np.concatenate((y2_pred1, y2_pred2, y2_pred3)).transpose()
print(result_distribution)

#result
result = np.argmax((result_distribution), axis = 1) + 1
print("testcase_number  "+"feature_value  "+"classify_result","expected_result")
for i in range(len(result)):
    print(i,'\t\t',str.format('{0:.3f}\t\t', x2_test.iloc[i]),result[i],'\t\t',y2_test.iloc[i])

print('accuracy: ',(y2_test==result).sum(),'/',len(y2_test))


def confusion_matrix():
    #pirj = predicted result i and actual result j
    p1r1, p1r2, p1r3, p2r1, p2r2, p2r3, p3r1, p3r2, p3r3 = 0,0,0,0,0,0,0,0,0
    for i in range(len(y2_test)):
        if(y2_test.iloc[i]==1):
            if(result[i]==1): p1r1+=1
            elif(result[i]==2): p2r1+=1
            else: p3r1+=1
        elif(y2_test.iloc[i]==2):
            if(result[i]==1): p1r2+=1
            elif(result[i]==2): p2r2+=1
            else: p3r2+=1
        else:
            if(result[i]==1): p1r3+=1
            elif(result[i]==2): p2r3+=1
            else: p3r3+=1
    print('\t\t\033[96mpredict\033[0;0m\t')
    print('\t\t\033[96m1\t2\t3\033[0;0m')
    print('\t\033[96m1\033[0;0m\t'+'\033[1m'+str(p1r1)+'\t'+str(p2r1)+'\t'+str(p3r1)+'\033[0;0m')
    print('\033[96mactual\t2\033[0;0m\t'+'\033[1m'+str(p1r2)+'\t'+str(p2r2)+'\t'+str(p3r2)+'\033[0;0m')
    print('\t\033[96m3\033[0;0m\t'+'\033[1m'+str(p1r3)+'\t'+str(p2r3)+'\t'+str(p3r3)+'\033[0;0m')
    return "\033[96m---------confusion_matrix---------\033[0;0m"
print(confusion_matrix())
print("acc: ",(y2_test==result).sum()/len(y2_test))


#visualization of result
#p(x|Ci)
input_pt = np.linspace(-10,10, num = 1000)
plt.plot(input_pt, stats.norm.pdf(input_pt,mean1,sd1)*pCi[0], 'r',         input_pt, stats.norm.pdf(input_pt,mean2,sd2)*pCi[1], 'g',         input_pt, stats.norm.pdf(input_pt,mean3,sd3)*pCi[2], 'b')
plt.xlim(-10,10)
plt.xlabel('x value')
plt.legend(['class1','class2','class3'])
plt.title('Approximate p(Ci|x) Distribution')
plt.show()

#visualization of result
#p(x|Ci)
input_pt = np.linspace(-10,10, num = 1000)
plt.plot(input_pt, stats.norm.pdf(input_pt,mean1,sd1), 'r',         input_pt, stats.norm.pdf(input_pt,mean2,sd2), 'g',         input_pt, stats.norm.pdf(input_pt,mean3,sd3), 'b')
plt.xlim(-10,10)
plt.xlabel('x value')
plt.legend(['class1','class2','class3'])
plt.title('p(x|Ci) Distribution')
plt.show()

#discriminant func
input_pt = np.linspace(-20,20, num = 1000)
plt.plot(input_pt, g(input_pt,1), 'r',         input_pt, g(input_pt,2), 'g',         input_pt, g(input_pt,3), 'b')
plt.ylim(-20,10)
plt.xlim(-20,20)
plt.xlabel('x value')
plt.legend(['class1','class2','class3'])
plt.title('Discriminant Function')
plt.show() 


