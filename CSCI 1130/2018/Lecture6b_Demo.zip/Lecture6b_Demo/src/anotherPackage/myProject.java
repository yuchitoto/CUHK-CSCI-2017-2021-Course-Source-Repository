/*
 * myProject.java
 *
 * Created on 2006�~06��07�� �P���T, �U��4:54
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package anotherPackage;

import myTools.QuadraticSolver;

/**
 *
 * @author pffung
 */
public class myProject {
    
    /** Creates a new instance of myProject */
    public myProject() {
        QuadraticSolver eqn;
        
        eqn = new myTools.QuadraticSolver(20, -34, -123);
        System.out.println(eqn);        // test the toString() method
        System.out.println("root 1 = " + eqn.root1());
        System.out.println("root 2 = " + eqn.root2());
    }
    
    public static void main(String[] args)
    {
        System.out.println("Running anotherPackage.myProject");
        new myProject();
        
        // this is invalid since class TestMyTools is NOT public
//        new myTools.TestMyTools();
    }
}
