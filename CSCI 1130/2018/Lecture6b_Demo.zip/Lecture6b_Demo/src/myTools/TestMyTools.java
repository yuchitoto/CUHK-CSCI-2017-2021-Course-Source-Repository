/*
 * TestMyTools.java
 *
 * Created on 2006�~06��07�� �P���T, �U��4:47
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package myTools;

/**
 *
 * @author pffung
 */

/** THIS IS NOT A public CLASS */
class TestMyTools {
    
    /** Creates a new instance of TestMyTools */
    public TestMyTools() {
        QuadraticSolver eqn;
        
        eqn = new QuadraticSolver(1, 5, 6);
        System.out.println(eqn);        // test the toString() method
        System.out.println("root 1 = " + eqn.root1());
        System.out.println("root 2 = " + eqn.root2());

        eqn = new QuadraticSolver(0, 2, 4);
        System.out.println(eqn);        // test the toString() method
        System.out.println("root 1 = " + eqn.root1());
        System.out.println("root 2 = " + eqn.root2());

        try {
            eqn = new QuadraticSolver(1, 1, 1);
            System.out.println(eqn);        // test the toString() method
            System.out.println("root 1 = " + eqn.root1());
            System.out.println("root 2 = " + eqn.root2());
        }
        catch (ArithmeticException obj_ref)
        {
            System.out.println(obj_ref);
        }
    }
    
    public static void main(String[] args)
    {
        System.out.println("Running myTools.TestMytools");
        new TestMyTools();
    }
}
