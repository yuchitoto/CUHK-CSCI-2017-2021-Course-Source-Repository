/*
 * QuadraticSolver.java
 *
 * Created on 2006�~06��07�� �P���T, �U��4:40
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package myTools;

/**
 *
 * @author pffung
 */
public class QuadraticSolver {

    /** this class represents a Quadratic Equation Solver */
    
    /**                                   2               */
    /** stores an equation of the form A x  + B x + C = 0 */
    private double A, B, C;
    
    /** Creates a new instance of QuadraticSolver */
    public QuadraticSolver(double coeff_A, double coeff_B, double coeff_C) {
        A = coeff_A;
        B = coeff_B;
        C = coeff_C;
    }
    
    public double det()
    {
        return B * B - 4 * A * C;
    }
    
    public double root1()
    {
        double d = det();
        if (d < 0)
            throw new ArithmeticException("Determinant is -ve, no real root.");
        if (A == 0)
            return -C / B;
        return (-B + Math.sqrt(d)) / 2.0 / A;
    }

    public double root2()
    {
        double d = det();
        if (d < 0)
            throw new ArithmeticException("Determinant is -ve, no real root.");
        if (A == 0)
            return -C / B;
        return (-B - Math.sqrt(d)) / 2.0 / A;
    }
    
    public String toString()
    {
        return "Equation (" + A + ") x^2 + (" + B + ") x + (" + C + ") = 0";
    }
}
