import javax.swing.JOptionPane;

class Family
{
  public static void main(String[] args)
  {
    JOptionPane.showMessageDialog(null, "Family main...");

    PoorHusband.action();
    AngryWife.action();
  }
}
