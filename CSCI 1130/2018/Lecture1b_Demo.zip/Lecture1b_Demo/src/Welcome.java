class Welcome
{
  /* Welcome program
   * ---------------
   * Illustrates a simple program displaying a message.
   */

  public static void main (String[] args)
  {
    System.out.println("Welcome to Java!");
  }
}
