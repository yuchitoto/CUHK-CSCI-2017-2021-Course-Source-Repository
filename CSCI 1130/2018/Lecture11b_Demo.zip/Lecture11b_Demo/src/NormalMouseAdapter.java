import java.awt.*;
import java.awt.event.*;

/*
 * This is a subclass of the class MouseAdapter
 * We override its methods to perform our desired function
 *
 * note that MouseAdapter implements the interface MouseListener
 */
class NormalMouseAdapter extends MouseAdapter
{
  public void mouseEntered(MouseEvent e)
  {
    System.out.println("[NormalMouseAdapter object].mouseEntered(MouseEvent) invoked");
    System.out.println("  Mouse Entered");
  }
  public void mouseClicked(MouseEvent e)
  {
    System.out.println("[NormalMouseAdapter object].mouseClicked(MouseEvent) invoked");
    System.out.println("  Mouse Clicked");
  }
}
