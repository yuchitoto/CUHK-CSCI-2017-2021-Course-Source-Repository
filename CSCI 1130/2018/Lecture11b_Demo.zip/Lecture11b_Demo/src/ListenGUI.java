import java.awt.*;
import java.awt.event.*;

/* this is the main class of this file */
class ListenGUI {
  public static void main(String[] args) {
    Frame myWindow = new Frame();
    myWindow.setTitle("Simple GUI");
    myWindow.setSize(200, 100);
    myWindow.setVisible(true);

    WindowAdapter myWindowAdapterObject = new MyWindowAdapter();
    myWindow.addWindowListener(myWindowAdapterObject);
  }
}

/* to minimize the number of files, we put this class in this file too */
class MyWindowAdapter extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
    System.out.println("Terminating the program!");
//    System.exit(1);
    System.out.println("Oops!  Virus intrusion, I can't stop...");
    ListenGUI.main(null);
  }
}

