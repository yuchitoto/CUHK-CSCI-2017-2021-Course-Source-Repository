import java.awt.*;
import java.awt.event.*;

/*
 * This is a subclass of the class WindowAdapter
 * We override its methods to perform our desired function
 *
 * Note that WindowAdapter implement the interface WindowListener
 */
class NormalWindowAdapter extends WindowAdapter
{
  public void windowClosing(WindowEvent e)
  {
    System.out.println("[NormalWindowAdapter object].windowClosing(WindowEvent) invoked");
    System.out.println("  Closing the window, program to be terminated...");
    System.exit(0);
  }
}
