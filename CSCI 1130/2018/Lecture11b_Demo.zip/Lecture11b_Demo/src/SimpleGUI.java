import java.awt.*;

/*
 * This is not the usual way we call up GUI
 * Normally, we should extend some GUI components
 * in order to modify the behaviour
 */
class SimpleGUI {
  public static void main(String[] args)
  {
    /* create a window object from the class Frame */
    Frame myWindow = new Frame();
    /* send instance messages to the new object in order to modify behaviour */
    myWindow.setTitle("Simple GUI");
    myWindow.setSize(200, 100);
    myWindow.setVisible(true);
  }
}
