import java.awt.*;
import java.awt.event.*;

/*
 * This is the usual way we call up GUI
 * Normally, we should extend some GUI components
 * in order to modify the behaviour
 * See later how we override some methods
 */
class NormalGUI extends Frame
{
  public NormalGUI()				/* constructor */
  {
//    this.setLayout(new GridLayout(2, 2));
    this.setLayout(new GridLayout(0, 3));

    // create a few GUI component objects
    Button button1 = new Button("Button 1");
    Button button2 = new Button("Button 2");
    Label label1 = new Label("Name: ");
    TextField text = new TextField();

    // add them to the object being construted (a NormalGUI object)
    this.add(button1);
    this.add(button2);
    this.add(label1);
    this.add(text);

    // register the listeners
    button1.addMouseListener(new NormalMouseAdapter());
    this.addWindowListener(new NormalWindowAdapter());
  }

  public static void main(String[] args)
  {
    // myWindow is a variable of type Frame
    // which may store an object reference of type NormalGUI
    // because NormalGUI extends (is a subclass of) Frame
    Frame myWindow = new NormalGUI();
    myWindow.setTitle("Simple GUI");
    myWindow.setSize(200, 100);
    myWindow.setVisible(true);
  }
}

