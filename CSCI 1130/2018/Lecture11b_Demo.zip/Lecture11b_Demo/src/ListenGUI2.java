import java.awt.*;
import java.awt.event.*;

// use of interface
class ListenGUI2 implements MouseMotionListener
{
  public static void main(String[] args) {
    Frame myWindow = new Frame();
    myWindow.setTitle("Simple GUI");
    myWindow.setSize(200, 100);
    myWindow.setVisible(true);
    myWindow.addMouseMotionListener(new ListenGUI2());
    // main finishes here BUT event dispatching loop picks up control
  }

  // methods in the interface MouseMotionListener
  public void mouseDragged(MouseEvent eventObject)
  {
    System.out.println("Mouse dragged at (" + eventObject.getX() + ", " + eventObject.getY() + ")");
  }
  public void mouseMoved(MouseEvent eventObject)
  {
    System.out.println("Mouse moved at (" + eventObject.getX() + ", " + eventObject.getY() + ")");
  }
}

