class TestUnicode {

  /*  Program to demonstrate Unicode      J M Bishop May 2000
   *  ==============================
   *
   *  Illustrates character casting, unicode
   *  and use of hexadecimal
   */

  TestUnicode() {
     for (char code = '\u0020' ; code <='\u00FF' ; code++) {
       System.out.print(Stream.format(code,5) + " " + code);
       if (code%10 == 0) {
         System.out.println();
       }
    }
  }

  public static void main (String [] args) {
    new TestUnicode();
  }
}
