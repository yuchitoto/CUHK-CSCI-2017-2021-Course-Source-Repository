class TestDecimalUnicode {

  /* modified by Michael on 26 Feb 2002 */

  /*  Program to demonstrate Unicode      J M Bishop May 2000
   *  ==============================
   *
   *  Illustrates character casting, unicode
   *  and use of decimal
   */

  // constructor
  TestDecimalUnicode()
  {
     System.out.println("Michael's Decimal Unicode printing example");
  
     // a for-loop going through a range of the Unicode
     for (int code = 32 ; code <= 127 ; code++)
     {
       // ***explicit*** type casting from the code to the corresponding character
       char characterToBePrinted = (char) code;
       
       // prints the code as well as the character nicely
       System.out.print(Stream.format(code,5) + " " + characterToBePrinted);
       
       // insert a newline for every eight codes
       if (code % 8 == 7) {
          System.out.print('\n');             // '\n' here is also a character itself
       }
     } // end of for-loop
  }

  public static void implicitTypeCasting()
  {
    // ***implicit*** type casting
    System.out.println("Example showing implicit type casting");
    char c = 'A';
    int n;
    n = c;          // auto-conversion
    System.out.println(c + "-->" + n);
    double d;
    d = c;          // auto-conversion
    System.out.println(c + "-->" + d);
    System.out.println();
  }

  public static void explicitTypeCasting()
  {
    // ***explicit*** type casting
    System.out.println("Example showing explicit type casting");
    int n = 65;
    char c;
    c = (char) n;  // explicit-conversion
    System.out.println("(char) " + n + "-->" + c);
    double d = 65.9;
    c = (char) d;  // explicit-conversion
    System.out.println("(char) " + d + "-->" + c);
    System.out.println();
  }
  
  public static void characterArithmetic()
  {
    // character arithmetic
    System.out.println("Example showing Unicode-based character arithmetic");

    char c = 'A';
    c++;
    System.out.println("'A' + 1 --> " + c);
    
    int difference = 'Z' - 'D';
    System.out.println("'Z' - 'D' --> " + difference);
    difference = 'H' - 'h';
    System.out.println("'H' - 'h' --> " + difference);
    difference = ';' - 'x';
    System.out.println("';' - 'x' --> " + difference);
    int answer = 'A' * 'j';
    System.out.println("'A' * 'j' --> " + answer);

    System.out.println();
  }

  public static void playWithHexUnicode()
  {
    // character arithmetic
    System.out.println("Play with hexadecimal Unicode");

    char c = '\u0041';
    System.out.println("'\\u0041' (base 16) --> " + c);
    
    System.out.println();
  }

  // beginning of the program
  public static void main (String [] args)
  {
    implicitTypeCasting();  
    explicitTypeCasting();
    characterArithmetic();
    playWithHexUnicode();
    new TestDecimalUnicode();      // creating a new object, thus calling the constructor
  }
}
