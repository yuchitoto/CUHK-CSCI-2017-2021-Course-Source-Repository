/**
 * Author: Michael FUNG
 * Date: 9 March 2006
 *
 * Description: Illustrate how to write text to a file in Unicode
 *
 * Finding: Java internally performs encoding for us in file I/O.
 *
 * IMPORTANT: UTF-16 depends on the Unicode character '\uFEFF' as a byte order mark.
 *            It is the first 2 bytes of the file, indicating Big/ Little Endianship.
 *            Internet Explorer, Notepad, and even VIM read and CONSUME these 2 bytes!
 *
 * See: http://java.sun.com/j2se/1.5.0/docs/api/java/io/PrintStream.html#PrintStream(java.lang.String, java.lang.String)
 *      http://java.sun.com/j2se/1.5.0/docs/api/java/nio/charset/Charset.html
 *
 * See: http://www.pccl.demon.co.uk/java/unicode.html
 *      (With Java Applets showing the Unicode char set)
 *
 * See: http://www.jorendorff.com/articles/unicode/java.html
 *      (With detailed explanation and sample code)
 */

import java.io.*;

class WriteUnicodeFile {
    public static void writeUnicode8(String filename) throws Exception {
        PrintStream outFile;
        outFile = new PrintStream(filename, "UTF-8");  // write file in 8-bit Unicode
        outFile.println("\u003C\u0048\u0054\u004D\u004C\u003E");
        outFile.println("\u0048\u0045\u004C\u004C\u004F");
        outFile.println("\u6211\u5F88\u597D");
        outFile.println("HELLO");
        outFile.println("�ګܦn");  // I'm fine in BIG5 Chinese
        outFile.println("\u003C\u002F\u0048\u0054\u004D\u004C\u003E");
        outFile.close();
    }

    public static void writeUnicode16(String filename) throws Exception {
        PrintStream outFile;
        outFile = new PrintStream(filename, "UTF-16");  // write file in 16-bit Unicode
        outFile.println("\u003C\u0048\u0054\u004D\u004C\u003E");
        outFile.println("\u0048\u0045\u004C\u004C\u004F");
        outFile.println("\u6211\u5F88\u597D");
        outFile.println("HELLO");
        outFile.println("�ګܦn");  // I'm fine in BIG5 Chinese
        outFile.println("\u003C\u002F\u0048\u0054\u004D\u004C\u003E");
        outFile.close();
    }

    public static void writePlaintext(String filename) throws Exception {
        PrintStream outFile;
        outFile = new PrintStream(filename);  // write file in default char set
        outFile.println("<HTML>");
        outFile.println("\u0048\u0045\u004C\u004C\u004F");
        outFile.println("\u6211\u5F88\u597D");
        outFile.println("HELLO");
        outFile.println("�ګܦn");  // I'm fine in BIG5 Chinese
        outFile.println("</HTML>");
        outFile.close();
    }

    public static void main(String[] args) throws Exception {
        WriteUnicodeFile.writeUnicode8("testUnicode8.htm");
        WriteUnicodeFile.writeUnicode16("testUnicode16.htm");
        WriteUnicodeFile.writePlaintext("testPlaintext.htm");
    }
}
