class Program3 {
  public static void main(String[] args)
  {                         /* outer block starts */
    int a = 1;
    System.out.println( a );
    {                         /* inner block starts */
      int a = 2, b = 3;
      a++;
      System.out.println("*** " + a );
      System.out.println("*** " + b );
    }                         /* inner block ends */
    System.out.println( a );
  }
}                         /* outer block ends */

class Program4s {
  public static void main(String[] args)
  {                         /* outer block starts */
    int a;
    for (int a = 0; a < 9; a++)  // What's the problem?
    {                         /* inner block starts */
    }                         /* inner block ends */

    for (int b = 0; b < 9; b++)
    {                         /* inner block starts */
    }                         /* inner block ends */
    System.out.println( b );     // What's the problem?
  }
}                         /* outer block ends */

