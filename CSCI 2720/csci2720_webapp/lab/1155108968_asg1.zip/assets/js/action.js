/* Name: Lam King Fung 
    SID: 1155108968    */

function showButtons()
{
    var e = document.getElementById("specials");
    if(e.style.display == "block")
       e.style.display = 'none';
    else
       e.style.display = 'block';
}

function alignChanges()
{
    var x = document.getElementsByTagName("h3");
    for(i = 0; i < x.length; i++)
    {
        if(x[i].classList.contains("text-start"))
        {
            x[i].classList.remove("text-start");
            x[i].classList.add("text-center");
        }
        else if(x[i].classList.contains("text-center"))
        {
            x[i].classList.remove("text-center");
            x[i].classList.add("text-end");
        }
        else if(x[i].classList.contains("text-end"))
        {
            x[i].classList.remove("text-end");
            x[i].classList.add("text-start");
        }
    }
    return;
}

function newHobby()
{
    var hobby = prompt("Enter a new hobby for me!");
    //console.log(hobby);
    if (hobby != "" && hobby != null)
    {
        var ul = document.getElementById("hobbies");
        var li = document.createElement("li");
        li.appendChild(document.createTextNode(hobby));
        li.classList.add("list-group-item");
        li.classList.add("list-group-item-info");
        //console.log(ul,li);
        ul.appendChild(li);
        //console.log(ul,li);
    }
    return;
}

window.onload = function() {
    loadComment();
};

window.onscroll = function() {progressBar()};
function progressBar()
{
  var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
  var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  var scrolled = (winScroll / height) * 100;
  document.getElementById("progressBar").style.width = scrolled + "%";
}

function processform()
{      
    //console.log("Testing");
    var nE = document.querySelector("#new-email");
    var nC = document.querySelector('#new-comment');
    var nEc = nE.value;
    var nCc = nC.value;
    //console.log(nEc, nCc);
    //console.log(nE.checkValidity() , nEc !== null, nCc !== null)

    if(nE.checkValidity() && nEc !== null && nCc !== null)
    {
        if(nE.classList.contains("is-invalid")) {nE.classList.remove("is-invalid");}
        if(nC.classList.contains("is-invalid")) {nC.classList.remove("is-invalid");}

        let newComment = document.createElement("div");
        let element = '<div><svg height="100" width="100"><circle cx="50" cy="50" r="40"></svg></div><div><h5></h5><p></p></div>';
        newComment.innerHTML = element;
        newComment.className = "d-flex";
        newComment.querySelectorAll("div")[0].className = "flex-shrink-0"; // 1st div
        newComment.querySelectorAll("div")[1].className = "flex-grow-1"; // 2nd di
        let lastComment = document.querySelector("#comments").lastElementChild; // instead of lastChild for div element
        newComment.id = 'c' + (Number(lastComment.id.substr(1)) + 1);

        newComment.querySelector("h5").innerHTML = document.querySelector("#new-email").value;
        newComment.querySelector("p").innerHTML = document.querySelector("#new-comment").value;

        let color = document.querySelectorAll("input[name=new-color]:checked")[0].value; // look for checked radio buttons
        newComment.querySelector("circle").setAttribute("fill", color);

        document.querySelector("#comments").appendChild(newComment);
        document.querySelector("form").reset() 
        
        saveComment();
        return;
    }else{

        if (!nE.checkValidity() || nEc == null)
        {
            nE.classList.add("is-invalid");
        }else{
            nE.classList.remove("is-invalid");
        }
        if (nCc == null || nCc == "")
        {
            nC.classList.add("is-invalid");
        }else{
            nC.classList.remove("is-invalid");
        }

        return;
    }
}

function saveComment()
{
    fetch('assets/comments.txt', {
        method: 'PUT',
        body: document.querySelector("#comments").innerHTML
        });
}

function loadComment()
{
    fetch('assets/comments.txt')
    .then(res => res.text())
    .then(txt => document.querySelector("#comments").innerHTML = txt)

    
}